// ============================================================
//  sw.js — Service Worker for Guts IOC PWA
// ============================================================
const CACHE_NAME = "guts-ioc-v1.2";
const STATIC_ASSETS = [
  "./index.html",
  "./manifest.json",
  "https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700&family=IBM+Plex+Sans+Thai:wght@400;600;700&display=swap"
];

// ── Install: cache static assets ──
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(() => {});
    })
  );
  self.skipWaiting();
});

// ── Activate: remove old caches ──
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ── Fetch Strategy ──
self.addEventListener("fetch", event => {
  const url = event.request.url;

  // Google Apps Script API — Network First (ต้องการข้อมูลล่าสุด)
  if (url.includes("script.google.com")) {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          // Cache ข้อมูลล่าสุดสำหรับ offline
          if (response.ok && event.request.url.includes("action") === false) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => {
          // Offline: ส่งข้อมูล cache กลับไป
          return caches.match(event.request).then(cached => {
            if (cached) return cached;
            // ส่ง JSON ว่างถ้าไม่มี cache
            return new Response(JSON.stringify([]), {
              headers: { "Content-Type": "application/json" }
            });
          });
        })
    );
    return;
  }

  // Google Fonts — Cache First
  if (url.includes("fonts.googleapis.com") || url.includes("fonts.gstatic.com")) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          return response;
        }).catch(() => new Response("", { status: 503 }));
      })
    );
    return;
  }

  // Static assets — Cache First with Network Fallback
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        // Fallback ไปที่ index.html สำหรับ navigation requests
        if (event.request.mode === "navigate") {
          return caches.match("./index.html");
        }
        return new Response("Offline", { status: 503 });
      });
    })
  );
});

// ── Background Sync (ถ้ามี queued actions) ──
self.addEventListener("sync", event => {
  if (event.tag === "sync-bookings") {
    event.waitUntil(syncPendingBookings());
  }
});

async function syncPendingBookings() {
  // ถ้า browser รองรับ background sync
  // pending bookings จะถูกส่งเมื่อออนไลน์
  const cache = await caches.open(CACHE_NAME);
  const pendingKey = "pending-bookings";
  const cached = await cache.match(pendingKey);
  if (cached) {
    const pending = await cached.json();
    for (const booking of pending) {
      try {
        await fetch(booking.url);
      } catch (e) {
        // ยังไม่สำเร็จ ไว้ sync ครั้งต่อไป
      }
    }
  }
}
