# 🚗 Guts IOC Fleet PWA

ระบบจองและเบิกรถ Guts IOC — Progressive Web App

## 📁 โครงสร้างไฟล์

```
guts-ioc-pwa/
├── index.html        ← ตัว App หลัก
├── manifest.json     ← PWA Manifest (ชื่อ, ไอคอน, theme)
├── sw.js             ← Service Worker (offline, cache)
├── icons/
│   ├── icon-192.png  ← App Icon (Android, Chrome)
│   └── icon-512.png  ← App Icon (Splash Screen)
└── README.md
```

## 🚀 วิธี Deploy บน GitHub Pages

### 1. สร้าง GitHub Repository

```bash
# สร้าง repo ใหม่ (ชื่อ: guts-ioc-fleet หรืออะไรก็ได้)
git init
git add .
git commit -m "Initial PWA commit"
git remote add origin https://github.com/<YOUR_USERNAME>/<REPO_NAME>.git
git push -u origin main
```

### 2. เปิด GitHub Pages

1. ไปที่ **Settings** ของ repo
2. เลือก **Pages** (ซ้ายมือ)
3. Source → **Deploy from a branch**
4. Branch → **main**, Folder → **/ (root)**
5. กด **Save**

รอ 1-2 นาที จะได้ URL:
```
https://<YOUR_USERNAME>.github.io/<REPO_NAME>/
```

### 3. ทดสอบ PWA

เปิดจาก Chrome/Safari บนมือถือ:
- **Android**: จะมีแจ้งเตือน "เพิ่มลงหน้าจอหลัก" อัตโนมัติ
- **iOS**: เปิด Safari → Share → "Add to Home Screen"
- **Desktop Chrome**: กดไอคอนติดตั้ง (⊕) ในแถบ URL

## ⚙️ การตั้งค่า Apps Script

ไฟล์ `code.gs` ไม่ต้องเปลี่ยนแปลง — Backend เหมือนเดิมทุกอย่าง

แค่ตรวจสอบว่า API URL ใน `index.html` ถูกต้อง:
```javascript
const API = "https://script.google.com/macros/s/...YOUR_SCRIPT_ID.../exec";
```

## 📱 ฟีเจอร์ PWA

| ฟีเจอร์ | รายละเอียด |
|---------|-----------|
| ✅ Installable | ติดตั้งได้บน Android, iOS, Desktop |
| ✅ Offline | ดูข้อมูล cache ได้เมื่อไม่มี internet |
| ✅ Auto Refresh | ดึงข้อมูลใหม่ทุก 30 วินาที |
| ✅ Splash Screen | หน้า loading สวยงาม |
| ✅ Dark Theme | UI สำหรับทำงานทั้งกลางวัน/กลางคืน |
| ✅ Bottom Nav | Navigation แบบ Native App |
| ✅ Toast Alerts | แจ้งเตือนแทน alert() |
| ✅ Safe Area | รองรับ iPhone notch/Dynamic Island |

## 🔐 รหัสผ่าน (ไม่มีการเปลี่ยน)

กำหนดใน `code.gs` ฝั่ง Google Apps Script เหมือนเดิม:
- Admin: `11223344`, `12121212`
- Keyman: `1234`, `4321`, `1122`

## 📝 หมายเหตุ

- Service Worker จะ cache ไฟล์ static ทั้งหมด
- ข้อมูลจาก API จะถูก cache ล่าสุดสำหรับ offline mode  
- เมื่อ deploy version ใหม่ ให้เปลี่ยน `CACHE_NAME` ใน `sw.js` (เช่น `v1.3`)
